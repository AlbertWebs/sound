<!-- The Pop Up -->

 <!-- Content -->

<?php $Orders = DB::table('orders')->inRandomOrder()->get();
$CountOrders = count($Orders);
$counter = 2;
$counter2 = 1;
?>

@if($Orders->isEmpty())

@else

@foreach($Orders as $order)
<?php $Order_product = DB::table('orders_products')->where('orders_id',$order->id)->get() ?>
@foreach($Order_product as $pro)
<?php $Product = DB::table('product')->where('id',$pro->products_id)->get() ?>
@foreach($Product as $product)
<div class="pop_{{$counter}} hide popper">
  <div class="error-msg">
    <span class="close">×</span>
    <div class="success-inner col-lg-12">
      <div class="popup-info-text col-lg-4">
        <img class="product-image" src="{{url('/')}}/uploads/product/{{$product->image_one}}" alt="product-image">
      </div>
      <?php $User = DB::table('users')->where('id',$order->user_id)->get() ?>
      @foreach($User as $user)
      <div class="play-btn col-lg-8">
        <p>Someone From {{$user->location}} has bought a <br> <a style="color:#66139" href="{{url('product')}}/{{$product->name}}">{{$product->name}}</a> <br> <?php $date = $order->created_at; $timeDiff = timeago($date); echo $timeDiff; ?> </p>
      </div>
      @endforeach
    </div>
  </div>
</div>

<div class="pop_{{$counter2}} hide popper">
    
</div>
<!-- end popi -->
@endforeach
@endforeach
<?php 
      $counter =  $counter + 2;
      $counter2 =  $counter2 + 2; 
?>
@endforeach



 <!-- Content -->
<script>
  var random = 1;


  $(document).ready(function(){
      
  setInterval(function() {
      var global_selector = $("[class^='pop_']");
      random = generateNonSuccessiveRand(1, global_selector.length, random);

      global_selector.addClass("hide").removeClass("show");
      $(".pop_" + random).removeClass("hide",250).addClass("show",250,function(){
          
      });
      // Check the Class Above, add class after a specified time interval
    },9000);
  })



function generateNonSuccessiveRand(min, max, previous) {
  var rand = Math.floor(Math.random() * max) + min;

  while (rand === previous) {
    rand = Math.floor(Math.random() * max) + min
  }

  return rand;
}
$('.close').click(function(){
  $(".pop_" + random).removeClass("show").addClass("hide");
  setInterval(function() {
      // Set the Intervals To zero hehehehe BadAss Walkaround eeeh?
      $(".pop_" + random).removeClass("show").addClass("hide");
    },0);
});
</script>
 <!-- </The Popup> -->

 @endif